/* GML Language Switcher - Frontend JS */
(function () {
    'use strict';

    /* ── 1. Dropdown toggle — teleport panel to <body> ── */
    function initDropdowns() {
        document.querySelectorAll('.gml-style-dropdown .gml-dropdown').forEach(function (dropdown) {
            var btn = dropdown.querySelector('.gml-dropdown-btn');
            var menu = dropdown.querySelector('.gml-dropdown-menu');
            if (!btn || !menu) return;
            var links = menu.querySelectorAll('a[href], .gml-language-unavailable');
            if (!links.length) return;

            // Retain a navigation ancestor for theme handlers already bound to links.
            var portal = document.createElement('nav');
            portal.className = 'gml-dropdown-portal main-nav';
            portal.setAttribute('aria-labelledby', menu.id);
            menu.style.setProperty('display', 'none', 'important');
            document.body.appendChild(portal);
            portal.appendChild(menu);
            menu.classList.add('gml-dropdown-teleported');

            // Store reference for positioning
            btn._gmlMenu = menu;
            menu._gmlBtn = btn;
            menu._gmlDropdown = dropdown;

            btn.addEventListener('click', function (e) {
                e.stopPropagation();
                var isOpen = dropdown.classList.contains('open');
                closeAllDropdowns();
                if (!isOpen) {
                    dropdown.classList.add('open');
                    btn.setAttribute('aria-expanded', 'true');
                    // Show first (off-screen) so we can measure, then position
                    menu.style.setProperty('display', 'block', 'important');
                    positionMenu(btn, menu);
                    if (e.detail === 0) links[0].focus();
                }
            });

            btn.addEventListener('keydown', function (e) {
                if (e.key !== 'ArrowDown' && e.key !== 'ArrowUp') return;
                e.preventDefault();
                closeAllDropdowns();
                dropdown.classList.add('open');
                btn.setAttribute('aria-expanded', 'true');
                menu.style.setProperty('display', 'block', 'important');
                positionMenu(btn, menu);
                links[e.key === 'ArrowUp' ? links.length - 1 : 0].focus();
            });
            menu.addEventListener('keydown', function (e) {
                var index = Array.prototype.indexOf.call(links, document.activeElement);
                if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
                    e.preventDefault();
                    links[(index + (e.key === 'ArrowDown' ? 1 : links.length - 1)) % links.length].focus();
                } else if (e.key === 'Tab' && ((e.shiftKey && index === 0) || (!e.shiftKey && index === links.length - 1))) {
                    // The teleported panel must return to header tab order.
                    if (e.shiftKey) e.preventDefault();
                    closeAllDropdowns();
                    btn.focus();
                }
            });
        });

        document.addEventListener('click', function (e) {
            // Don't close if clicking inside a teleported menu
            if (e.target.closest('.gml-dropdown-teleported')) return;
            closeAllDropdowns();
        });

        document.addEventListener('keydown', function (e) {
            if (e.key !== 'Escape') return;
            var panel = document.activeElement.closest('.gml-dropdown-teleported');
            closeAllDropdowns();
            if (panel && panel._gmlBtn) panel._gmlBtn.focus();
        });
        document.addEventListener('focusin', function (e) {
            if (!e.target.closest('.gml-dropdown, .gml-dropdown-teleported')) closeAllDropdowns();
        });

        // Reposition on scroll/resize
        var reposTimer;
        function onRepos() {
            clearTimeout(reposTimer);
            reposTimer = setTimeout(function () {
                document.querySelectorAll('.gml-dropdown.open').forEach(function (d) {
                    var b = d.querySelector('.gml-dropdown-btn');
                    if (b && b._gmlMenu) positionMenu(b, b._gmlMenu);
                });
            }, 16);
        }
        window.addEventListener('scroll', onRepos, true);
        window.addEventListener('resize', onRepos);
    }

    function closeAllDropdowns() {
        document.querySelectorAll('.gml-dropdown.open').forEach(function (d) {
            d.classList.remove('open');
            var b = d.querySelector('.gml-dropdown-btn');
            if (b) {
                b.setAttribute('aria-expanded', 'false');
                if (b._gmlMenu) b._gmlMenu.style.setProperty('display', 'none', 'important');
            }
        });
    }

    function positionMenu(btn, menu) {
        var rect = btn.getBoundingClientRect();
        if (!rect.width || !rect.height) {
            closeAllDropdowns();
            return;
        }
        var scrollX = window.pageXOffset || document.documentElement.scrollLeft;
        var scrollY = window.pageYOffset || document.documentElement.scrollTop;
        menu.style.setProperty('max-height', 'none');
        var below = Math.max(0, window.innerHeight - rect.bottom - 12);
        var above = Math.max(0, rect.top - 12);
        var openAbove = menu.offsetHeight > below && above > below;
        menu.style.setProperty('max-height', (openAbove ? above : below) + 'px');
        var menuWidth = menu.offsetWidth || 160;

        var alignment = btn.getAttribute('data-panel-align') || 'auto';

        // Position below the button using the selected alignment. Automatic
        // alignment keeps the panel inside the viewport without layout shifts.
        var top = openAbove ? rect.top + scrollY - menu.offsetHeight - 4 : rect.bottom + scrollY + 4;
        var left;
        if (alignment === 'left') {
            left = rect.left + scrollX;
        } else if (alignment === 'right') {
            left = rect.right + scrollX - menuWidth;
        } else {
            left = rect.left + menuWidth <= document.documentElement.clientWidth - 8
                ? rect.left + scrollX
                : rect.right + scrollX - menuWidth;
        }

        // Clamp to viewport
        if (left < 8) left = rect.left + scrollX;
        if (left + menuWidth > document.documentElement.clientWidth - 8) {
            left = document.documentElement.clientWidth - menuWidth - 8 + scrollX;
        }

        menu.style.setProperty('position', 'absolute', 'important');
        menu.style.setProperty('top', top + 'px', 'important');
        menu.style.setProperty('left', left + 'px', 'important');
    }

    /* ── 2. Menu / container style sync ──
     *
     * When the switcher is placed inside a <li> that's part of a UL/OL
     * (nav menu, footer list, sidebar widget list), we copy the computed
     * typography of a sibling link into the switcher so it blends in.
     *
     * Without this, the switcher uses pure CSS inheritance which only
     * carries as far as direct ancestor rules apply. Many themes style
     * their links via `.nav-menu a { ... }` selectors that don't match
     * our <button>, leaving the switcher with default browser styles.
     */
    function initMenuStyleSync() {
        document.querySelectorAll('.gml-language-switcher').forEach(function (switcher) {
            syncSwitcherToContext(switcher);
        });
    }

    /**
     * Find the best "typography reference" element in the switcher's
     * surroundings and copy its computed styles onto the switcher.
     *
     * Priority: sibling menu link > sibling link anywhere > closest
     * header/footer/nav link > any link inside the closest meaningful
     * wrapper (header / footer / aside / .widget).
     *
     * If no reference is found, rely on pure CSS inheritance — which
     * is still correct in well-built themes.
     */
    function syncSwitcherToContext(switcher) {
        var refLink = findReferenceLink(switcher);
        if (!refLink) return;

        var cs = window.getComputedStyle(refLink);

        var btn = switcher.querySelector('.gml-dropdown-btn');
        var btnLabel = btn ? btn.querySelector('.gml-lang-label') : null;
        var targets = [switcher];
        if (btn) targets.push(btn);
        if (btnLabel) targets.push(btnLabel);

        switcher.querySelectorAll('.gml-lang-button').forEach(function (b) {
            targets.push(b);
            var l = b.querySelector('.gml-lang-label');
            if (l) targets.push(l);
        });

        var props = [
            'fontFamily', 'fontSize', 'fontWeight', 'fontStyle',
            'color', 'lineHeight', 'letterSpacing',
            'textTransform', 'textDecoration'
        ];

        targets.forEach(function (el) {
            props.forEach(function (prop) {
                el.style.setProperty(
                    prop.replace(/([A-Z])/g, '-$1').toLowerCase(),
                    cs[prop],
                    'important'
                );
            });
        });

        // If in a menu, also mirror the sibling <li>'s padding/margin
        var li = switcher.closest('li');
        if (li) {
            var refLi = refLink.closest('li');
            if (refLi && refLi !== li) {
                var liCs = window.getComputedStyle(refLi);
                ['padding', 'paddingTop', 'paddingRight', 'paddingBottom', 'paddingLeft',
                 'margin',  'marginTop',  'marginRight',  'marginBottom',  'marginLeft'
                ].forEach(function (p) {
                    li.style[p] = liCs[p];
                });
            }

            // Mirror the link's padding onto the trigger so click target matches
            if (btn) {
                ['paddingTop', 'paddingRight', 'paddingBottom', 'paddingLeft'
                ].forEach(function (p) {
                    btn.style.setProperty(
                        p.replace(/([A-Z])/g, '-$1').toLowerCase(),
                        cs[p],
                        'important'
                    );
                });
            }
        }

        switcher.classList.add('gml-style-synced');
    }

    /**
     * Locate a reference link to inherit typography from.
     * Tries sibling menu-item links first, then other links in the same
     * structural wrapper (header / footer / nav / aside / widget).
     */
    function findReferenceLink(switcher) {
        // 1) Sibling inside the same <ul>/<ol>
        var li = switcher.closest('li');
        if (li) {
            var list = li.parentElement;
            if (list && (list.tagName === 'UL' || list.tagName === 'OL')) {
                var siblings = list.children;
                for (var i = 0; i < siblings.length; i++) {
                    var sib = siblings[i];
                    if (sib === li || sib.tagName !== 'LI') continue;
                    var a = sib.querySelector('a');
                    if (a && !a.closest('.sub-menu') && !a.closest('.gml-language-switcher')) {
                        return a;
                    }
                }
            }
        }

        // 2) Walk up to a semantic wrapper and grab a link inside it
        var wrappers = ['header', 'footer', 'nav', 'aside', '.widget', '.site-header', '.site-footer'];
        for (var j = 0; j < wrappers.length; j++) {
            var sel = wrappers[j];
            var wrap = sel.charAt(0) === '.' ? switcher.closest(sel) : switcher.closest(sel);
            if (wrap) {
                var links = wrap.querySelectorAll('a');
                for (var k = 0; k < links.length; k++) {
                    var l = links[k];
                    if (!l.closest('.gml-language-switcher') && !l.closest('.sub-menu')) {
                        return l;
                    }
                }
            }
        }

        return null;
    }

    /* ── 3. Internal link rewriting ── */
    function initLinkRewriting() {
        if (typeof gmlData === 'undefined') return;

        var currentLang = gmlData.currentLang;
        var sourceLang  = gmlData.sourceLang;
        var languages   = gmlData.languages;
        var homeUrl     = gmlData.homeUrl;
        var homePath    = (gmlData.homePath || '').replace(/\/$/, '');

        if (!currentLang || currentLang === sourceLang) return;
        if (languages.indexOf(currentLang) === -1) return;

        var home;
        try {
            home = new URL(homeUrl);
        } catch (error) {
            return;
        }
        var prefix = '/' + currentLang + '/';
        var excludedPaths = gmlData.excludedPaths || [];
        var knownLanguages = gmlData.knownLanguages || languages;
        var filePattern = gmlData.filePattern ? new RegExp(gmlData.filePattern, 'i') : null;

        function rewriteUrl(element, attribute) {
            var href = element.getAttribute(attribute);
            // Relative paths, queries and fragments resolve against the current page.
            if (!href || !/^(https?:\/\/|\/)/i.test(href)) return;
            if (/[\x00-\x20\x7f\\]/.test(href) || /\/(?:\.|%2e){1,2}(?:\/|[?#]|$)/i.test(href)) return;
            if (element.matches('a[download]')) return;
            if (element.closest('.gml-language-switcher, .gml-dropdown-teleported, [translate="no"]')) return;

            var url;
            try {
                url = new URL(href, document.baseURI);
            } catch (error) {
                return;
            }
            if (!/^https?:$/.test(url.protocol) || url.origin !== home.origin || url.username || url.password) return;
            var path = url.pathname;
            if (homePath && path !== homePath && path.indexOf(homePath + '/') !== 0) return;
            var checkedPath;
            try {
                checkedPath = decodeURIComponent(path);
            } catch (error) {
                return;
            }
            if (excludedPaths.some(function (excluded) {
                return checkedPath.toLowerCase() === excluded.toLowerCase() || checkedPath.toLowerCase().indexOf(excluded.toLowerCase() + '/') === 0;
            })) return;

            var relative = checkedPath.slice(homePath.length) || '/';
            if (/^\/(wp-admin|wp-login\.php|wp-json|wp-cron(?:\.php)?|wp-content|wp-includes)(\/|$)/i.test(relative)) return;
            if (knownLanguages.indexOf(relative.split('/')[1].toLowerCase()) !== -1) return;
            if (/(?:^|\/)feed(?:\/|$)/i.test(relative) || (filePattern && filePattern.test(relative))) return;
            var serviceQuery = false;
            url.searchParams.forEach(function (value, name) {
                if (/^(wc-ajax|action|rest_route|feed)$/i.test(name)) serviceQuery = true;
            });
            if (serviceQuery) return;

            // Preserve the original query and fragment, including signed URL encoding.
            var suffixIndex = href.search(/[?#]/);
            var suffix = suffixIndex === -1 ? '' : href.slice(suffixIndex);
            var destination = homePath + prefix + (path.slice(homePath.length) || '/').replace(/^\//, '') + suffix;
            if (/^(https?:\/\/|\/\/)/i.test(href)) destination = home.origin + destination;
            if (destination !== href) element.setAttribute(attribute, destination);
        }

        function rewriteElement(element) {
            if (element.matches('a[href]')) rewriteUrl(element, 'href');
            if (element.matches('form[action]')) rewriteUrl(element, 'action');
        }

        function rewriteLinks(root) {
            if (root.nodeType === 1) rewriteElement(root);
            root.querySelectorAll('a[href], form[action]').forEach(rewriteElement);
        }

        rewriteLinks(document);

        if (typeof MutationObserver !== 'undefined') {
            var observer = new MutationObserver(function (mutations) {
                mutations.forEach(function (mutation) {
                    if (mutation.type === 'attributes') {
                        rewriteElement(mutation.target);
                        return;
                    }
                    mutation.addedNodes.forEach(function (node) {
                        if (node.nodeType === 1) rewriteLinks(node);
                    });
                });
            });
            observer.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['href', 'action'] });
        }
    }

    /* ── Init ── */
    function init() {
        initDropdowns();
        initMenuStyleSync();
        initLinkRewriting();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
