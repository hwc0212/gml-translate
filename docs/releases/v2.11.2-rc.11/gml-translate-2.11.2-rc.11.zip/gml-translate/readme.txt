=== GML Translate ===
Contributors: huwencai
Tags: translate, multilingual, ai, hreflang, language switcher
Requires at least: 6.0
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 2.11.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

AI multilingual translation for WordPress with stable language URLs, editable translations, glossary, queue controls, hreflang, and sitemap integration.

== Description ==

GML Translate is a standalone multilingual plugin focused on stable WordPress language routing and maintainable AI-assisted translation.

Multilingual Site and AI Translation are separate states. Removing a provider key, exhausting quota, pausing the queue, or disabling AI Translation only stops new AI work. Existing translated pages, saved translations, language URLs, switchers, manual translations, hreflang, and sitemap variants remain available.

= Features =

* Language-prefixed WordPress routes and subdirectory-safe URL handling; external-domain mappings stay fail-closed until remote readiness can be verified.
* Google Gemini, DeepSeek, Qwen, and OpenAI translation providers.
* Bounded, resumable queue with locks, failure states, circuit breaking, and per-language manual recovery.
* Translation memory, current-page lookups, manual translation editor, glossary, protected terms, and exclusion rules.
* Content crawler that runs only in admin/WP-Cron and uses signed same-site requests.
* Menu, shortcode, widget, and automatic language switcher positions with theme, outline, and solid appearance presets.
* Browser-language detection.
* Optional exact-snapshot Human Review and a derived Publication Gate shared by routes, switchers, canonical, hreflang, and multilingual sitemaps.
* Redis/Memcached-safe cache generation invalidation without whole-site cache flushes.

= Relationship with GML AI SEO =

If you only need multilingual translation, use GML Translate.

Use one established SEO authority such as SEOPress, Yoast, or Rank Math for complete SEO management. GML Translate adds only the multilingual relationships that are safe to publish.

GML SEO is in LTS and still includes its existing multilingual host for compatibility. Installing both is normally unnecessary.

When both are active, GML Translate keeps the multilingual runtime until an administrator confirms handover, while GML SEO owns final canonical, meta, Open Graph, Schema, hreflang, and sitemap output. Existing data is never silently deleted.

== Installation ==

1. Upload and activate GML Translate.
2. Select source and destination languages.
3. Enable Multilingual Site and verify language routes before using AI.
4. Save a key for Gemini, DeepSeek, Qwen, or OpenAI, then enable AI Translation if new translations are needed.
5. Translate one language and a small page sample first.
6. Review glossary, links, layout, forms, canonical, hreflang, and sitemap before crawling the full site.

== Frequently Asked Questions ==

= Do translated pages disappear when the API key is removed? =

No. Existing multilingual output remains available. Only new AI translation work stops.

= Does the frontend call Gemini or DeepSeek? =

No. Ordinary frontend requests only perform routing, cache and translation lookups, lightweight rendering, and minimum multilingual SEO output.

= Can I edit AI translations? =

Yes. Manual translations are stored separately and take priority over normal automatic work.

= Is GML Translate a complete SEO plugin? =

No. It provides only the minimum multilingual SEO output. Use GML AI SEO or another single SEO authority for complete SEO management.

= What happens to my translations if I delete the plugin? =

All data is retained by default, including saved and manual translations, settings, glossary, queue, and encrypted provider credentials. To remove everything, first select permanent removal under Settings > Uninstall Data Retention and type DELETE exactly. Deactivation and normal updates never delete stored data.

= What happens while a language page is incomplete? =

Valid language URLs remain accessible while translation is incomplete. Missing text uses the source language, and the page shows a translation-in-progress notice. Search publication follows the current page-by-language readiness policy (98 percent by default, with critical content and review protections); incomplete pages remain noindex and outside hreflang/sitemaps until ready.

== Changelog ==

= 2.11.1-rc.20 =
* Locks Translation Core 0.9.3 with bounded same-origin permanent redirect discovery and explicit terminal resource relationships.
* Excludes redirected sources from every public language cluster without copying destination manifests; failed and temporary targets remain blocking.
* Adds two nullable schema fields and fail-closed upgrade guards, retained retired-resource history, and bounded dirty-overflow recovery.
* Uses database-authoritative cache generations to prevent pre-commit Redis refill races from reviving stale HTML.
* Adds a narrow source-relative contamination guard and administrator-only, snapshot-safe quality holds that preserve original text and manual translations.
* Does not automatically delete historical failures, empty Translation Memory, resume paid translation work, or change provider output budgets.

= 2.11.1-rc.19 =
* Updates Translation Core to 0.9.2 and requires 100 percent coverage of the exact current page manifest before a translated route is public.
* Reuses unchanged and manual translations, queues only new or changed current strings, and removes deleted strings from current readiness without deleting historical Translation Memory.
* Keeps incomplete targets out of public switchers, hreflang, and sitemap clusters while retaining the temporary source redirect and protected administrator preview.
* Makes per-page Human Review optional by default while preserving exact-snapshot approval, rejection, CAS, transactions, and audit records; a current rejection always blocks publication.
* Invalidates all dependent manifests after reusable builder or template content changes, using bounded background rediscovery without synchronous rendering or provider calls on save.
* Adds root/subdirectory redesign regressions for content, SEO metadata, changed links, manual translations, historical retention, and no real AI requests.

= 2.11.1-rc.18 =
* Updates Translation Core to 0.9.1 and derives public eligibility from machine completeness, exact-snapshot Human Review, source indexability, local language enablement, and route validity.
* Temporarily redirects anonymous visitors from ineligible local translated routes to the corresponding source URL while retaining a visibly marked, noindex administrator preview.
* Makes routes, language switchers, canonical adaptation, hreflang, and sitemap output consume the same publication decision.
* Integrates approved multilingual sitemap clusters with SEOPress, Yoast, and Rank Math, listing every eligible language URL independently with reciprocal alternates.
* Removes resources with no eligible URLs, preserves image/video/news sitemap namespaces, and batches URL resolution and eligibility reads.
* Counts target strings already translated by the Gettext pipeline as request-local rendered translations, avoiding false incomplete pages without extra database reads.
* Uses the GML sitemap as the sole sitemap authority only when no supported SEO plugin is active; existing cross-server mappings remain fail-closed as external_unverified in this RC.
* Does not start AI, resume queues, approve resources, delete translations, or perform production changes during upgrade.

= 2.11.1-rc.17 =
* Updates Translation Core to 0.8.1 and binds every approval or rejection to the exact manifest, translation, machine-state, and review-revision snapshot displayed to the reviewer.
* Rejects stale, incomplete, concurrent, or replayed decisions without recording partial success; review writes require POST, administrator capability, and a valid WordPress nonce.
* Requires InnoDB for all tables participating in the atomic review transaction and disables decisions with an actionable health message when transaction safety is unavailable.
* Prevents automatic imports or queue writes from replacing a concurrent manual translation at the database mutation boundary.
* Routes the Weglot importer through the Core Translation Memory service so imports, readiness invalidation, and review invalidation share one protected write contract.
* Adds language and effective review-state filters while keeping review strictly one resource and one language at a time.
* Strengthens clean-room database preflight so an empty or invalid WordPress installation cannot be reported as a passing regression run.
* Keeps Phase 2C.1 shadow-only: review decisions still do not publish, hide, route, index, or alter canonical, hreflang, Sitemap, switcher, or anonymous access.

= 2.11.1-rc.16 =
* Updates Translation Core to 0.8.0 and separates machine readiness from explicit human review.
* Lets administrators review and approve or reject one exact local resource-language snapshot at a time, with no bulk-approval bypass.
* Binds decisions to manifest, global, and translation generations so real source or translated-text changes make old decisions stale.
* Keeps identical authoritative rescans idempotent and commits translation writes, readiness invalidation, and approval invalidation atomically.
* Adds current decisions, translation generations, and append-only audit history without copying source or translated page text into audit rows.
* Keeps Phase 2C shadow-only: decisions do not publish, hide, route, index, or change canonical, hreflang, Sitemap, switcher, or anonymous access.
* Adds a direct MariaDB test preflight and retains full no-provider root/subdirectory regression coverage.

= 2.11.1-rc.15 =
* Updates Translation Core to 0.7.2 and calculates language progress and public readiness from unique source hashes in the completed current resource manifest.
* Excludes removed or replaced redesign text from normal queue batches, limited retries, and safety-circuit counts without deleting historical queue or Translation Memory records.
* Separates current pending, failed, and not-queued work from stored history in the Translation administration screen.
* Fails closed until the full current-content inventory is complete and free of current render errors.
* Keeps frontend readiness lightweight by avoiding historical queue scans and briefly caches actionable failure counts with complete invalidation.
* Preserves the 95 percent coverage threshold and complete critical SEO text requirement; machine readiness is not Human Approval.
* Makes no schema, provider, prompt, URL, uninstall, automatic-start, or data-deletion change.

= 2.11.1-rc.14 =
* Updates Translation Core to 0.7.1 and replaces the lossy single-hash continuation cursor with durable database readiness work state.
* Atomically marks every current resource/language row affected by a Translation Memory change stale before bounded background recalculation.
* Rebuilds at most 500 rows under an owner-token lease and recovers expired rebuilding rows after PHP, Cron, process, or server interruption.
* Deduplicates overlapping hashes by the existing unique resource/language row and prevents an older worker from overwriting a newer invalidation.
* Adds only the status_id readiness index; Translation Memory, queues, manual translations, glossary, exclusions, routes, and public multilingual output remain unchanged.
* Remains shadow-only and makes no Human Approval, canonical, hreflang, Sitemap, switcher, route-gate, or AI provider change.

= 2.11.1-rc.13 =
* Updates Translation Core to 0.7.0 with additive resource manifests, source-hash relationships, and per-resource/language machine-readiness snapshots.
* Requires all critical SEO hashes and at least 95% of the current resource manifest without treating manual Translation Memory as human publication approval.
* Uses bounded, signed, cookie-free, same-install HTTP 200 HTML renders and fails closed as render_error.
* Invalidates only an edited resource; global presentation changes advance one generation and schedule five-resource background batches.
* Keeps discovery and readiness operational with AI disabled and never starts paid AI work during shadow backfill.
* Adds object-aware single and bulk provider APIs without changing public canonical, hreflang, Sitemap, switcher, or anonymous access.
* Verifies one query for one resource and two indexed bulk queries for 1000 resources across root and subdirectory installations.

= 2.11.1-rc.12 =
* Updates Translation Core to 0.6.2 with atomic database compare-and-swap leases and one deferred rewrite refresh after routing imports.
* Prevents competing stale takeovers and prevents an expired or wrong owner from releasing a newer lock.
* Restricts processing-row recovery and late provider-result writes to the current queue owner.
* Preserves legacy lock values and makes no schema, translation, provider, URL, readiness, or multilingual SEO changes.
* Makes the language-switcher shortcode safe inside another plugin's output-buffer callback through a shared string renderer.

= 2.11.1-rc.11 =
* Retains all plugin data by default when the plugin is deleted, allowing a later reinstall to reuse it.
* Adds an explicit permanent-removal preference protected by an exact typed DELETE confirmation.
* Removes translation tables, legacy tables, settings, credentials, glossary, jobs, and dedicated cache only during confirmed WordPress uninstall.
* Protects shared translation data while GML AI SEO remains installed and handles multisite preferences per site.
* Hides every switcher surface and multilingual discovery tag on real 404 responses instead of manufacturing translated 404 links.
* Verifies reciprocal hreflang for index-ready pages while incomplete translations remain noindex and unadvertised.

= 2.11.1-rc.10 =
* Adds per-language local or external-site delivery for independent domains and subdomains.
* Supports same-path mapping or a safe external-homepage fallback without copying query strings across domains.
* Keeps external languages out of local rewrite rules, crawling, glossary work, and AI translation queues.
* Adds switcher appearance presets and automatic, left, or right dropdown alignment.
* Emits external hreflang only where a valid equivalent can be represented; remote sites are never modified.

= 2.11.1-rc.9 =
* Tracks published source changes incrementally without starting AI or resuming a paused queue.
* Adds Qwen and OpenAI alongside Gemini and DeepSeek with separate encrypted credentials.
* Reduces token use through duplicate removal and relevant-only glossary and protected-term context.
* Preserves and locally reuses technical-only values such as comparison limits and dimensions.

= 2.11.1-rc.8 =
* Classifies historical and current translation failures without changing existing tables.
* Uses bounded automatic cooldown for HTTP 429, 5xx, network and timeout failures without consuming item attempts.
* Keeps configuration failures safety-paused and failed retries limited to 25 items per language.
* Adds redacted recent-failure details and prevents a small historical tail from suppressing an otherwise complete language.

= 2.11.1-rc.3 =
* Fail locally on unreadable saved credentials and verify encrypted writes by reading them back.
* Separate local Save Changes from Test Saved AI Connection; neither resumes AI work.
* Preserve legacy encrypted keys, translation tables, multilingual routes and existing translations.
* Candidate only: real provider access and production recovery still require verification.

= 2.11.1-rc.2 =
* Separate content discovery from AI processing and report scheduled versus active batches accurately.
* Refresh rendered-page cache without deleting translation memory, manual edits or queued work.
* Preserve technical dimensions, operators and SKU symbols in translated text, titles, metadata and alt text.
* Release candidate only. Missing site translations still require bounded validation and completion.

= 2.11.1-rc.1 =
* Release candidate for staging verification, not a production-verified stable release.
* Prevent blocking translation upgrades: no frontend migration, no legacy-table ALTER or automatic deduplication, nonblocking setup lock and failure recovery.
* Restore explicit Auto-Translate start from an ordinary pause while retaining provider, sample, permission and scheduling safeguards.
* Preserve existing translation data and add real WordPress 7.1 / MariaDB large-queue and concurrency regression tests.

= 2.11.0 =

* Renamed the public product to GML Translate while preserving its folder, text domain, options, tables, and URLs.
* Adopted a locked, build-time vendored shared Translation Core with no runtime dependency.
* Separated multilingual availability from AI translation.
* Added safe dual-plugin behavior and deferred final SEO output to GML AI SEO when both are active.
* Centralized secure provider transport, bounded queue/crawler work, current-page lookups, and Redis-safe invalidation.
* Expanded regression coverage for state, routes, subdirectories, output ownership, transport, queue/cache, parser, crawler, installer, rules, and admin registration.

See CHANGELOG.md and GitHub Releases for complete release history.
